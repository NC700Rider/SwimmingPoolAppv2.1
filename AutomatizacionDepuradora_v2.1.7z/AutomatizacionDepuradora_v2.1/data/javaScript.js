
let jsonDoc;
let heartbeatRetries = 0;
const btnDepuradora = document.querySelector('.botonDepuradora');
const btnLuz = document.querySelector('.botonLuz');
const btnBomba = document.querySelector('.botonBomba');
const btnApCambios = document.querySelector('.applyChangesButton');

queryJson();
setInterval(heartbeat, 5000);

btnDepuradora.addEventListener('click', updateBtnDepuradora);
btnLuz.addEventListener('click', updateBtnLuz);
btnBomba.addEventListener('click', updateBtnBomba);
btnApCambios.addEventListener('click', updateBtnApCambios);

function updateBtnDepuradora() {
  if (btnDepuradora.textContent === 'Activar Depuradora') {
    btnDepuradora.textContent = 'Parar Depuradora';
    btnDepuradora.style.backgroundColor = "red";
    btnDepuradora.style.color = "black";
    jsonDoc["gestionManual"]["depuradora"] = true;
    console.log(jsonDoc);
    postJson(false);
  } else {
    btnDepuradora.textContent = 'Activar Depuradora';
    btnDepuradora.style.backgroundColor = "green";
    btnDepuradora.style.color = "white";
    jsonDoc["gestionManual"]["depuradora"] = false;
    console.log(jsonDoc);
    postJson(false);
  }
}

function updateBtnLuz() {
    if (btnLuz.textContent === 'Encender Luz') {
        btnLuz.textContent = 'Apagar Luz';
        btnLuz.style.backgroundColor = "red";
        btnLuz.style.color = "black";
      jsonDoc["gestionManual"]["luz"] = true;
      console.log(jsonDoc);
      postJson(false);
    } else {
        btnLuz.textContent = 'Encender Luz';
        btnLuz.style.backgroundColor = "green";
        btnLuz.style.color = "white";
      jsonDoc["gestionManual"]["luz"] = false;
      console.log(jsonDoc);
      postJson(false);
    }
}

function updateBtnBomba() {
    if (btnBomba.textContent === 'Activar Bomba') {
        btnBomba.textContent = 'Parar Bomba';
        btnBomba.style.backgroundColor = "red";
        btnBomba.style.color = "black";
      jsonDoc["gestionManual"]["bomba"] = true;
      console.log(jsonDoc);
      postJson(false);
    } else {
        btnBomba.textContent = 'Activar Bomba';
        btnBomba.style.backgroundColor = "green";
        btnBomba.style.color = "white";
      jsonDoc["gestionManual"]["bomba"] = false;
      console.log(jsonDoc);
      postJson(false);
    }
}

function updateBtnApCambios () {
    for (let i = 1; i < 5; i++)
    {
        let horaArranque = parseInt(document.querySelector(`.p${i}starttime`).value.slice(0,2)) * 60 + parseInt(document.querySelector(`.p${i}starttime`).value.slice(3,5));
        let horaParada = parseInt(document.querySelector(`.p${i}stoptime`).value.slice(0,2)) * 60 + parseInt(document.querySelector(`.p${i}stoptime`).value.slice(3,5));
        
        if (horaArranque > horaParada)
        {
            alert("La hora Start es mayor o igual que la hora de Stop\nPor favor, modificalo y vuelve a aplicar los cambios");
            return;
        }
    }
    if (!checkIpAddress(document.querySelector(".ipAddress").value))
    {
        alert("La dirección IP introducida no es valida");
        return;
    }
    if (!checkIpAddress(document.querySelector(".mask").value))
    {
        alert("La mascara de red introducida no es valida");
        return;
    }
    if (!checkIpAddress(document.querySelector(".gtw").value))
    {
        alert("La dirección IP del Gateway introducida no es valida");
        return;
    }
    if (!checkIpAddress(document.querySelector(".mask").value))
    {
        alert("La dirección IP del DNS introducida no es valida");
        return;
    }
    postJson(true);
}

function checkIpAddress(ipAddress)
{
    if (ipAddress == "")
    {
        return true;
    }
    const octetos = ipAddress.split('.');
    for (let i = 0; i < 4; i++)
    {
        if ((parseInt(octetos[i]) > 255) || (parseInt(octetos[i]) < 0))
        {
            return false;
        }
    }
    return true;
}

function postJson(toBeSave) {

    let xhttp = new XMLHttpRequest;

    if (toBeSave)
    {

        jsonDoc["escribir"] = toBeSave;
        for (let i = 1; i < 5; i++)
        {
            let horas = parseInt(document.querySelector(`.p${i}starttime`).value.slice(0,2));
            let minutos = parseInt(document.querySelector(`.p${i}starttime`).value.slice(3,5));
            console.log(horas);
            console.log(minutos);
            jsonDoc["programas"][i]["horaArranque"] = horas * 60 + minutos;
            horas = parseInt(document.querySelector(`.p${i}stoptime`).value.slice(0,2));
            minutos = parseInt(document.querySelector(`.p${i}stoptime`).value.slice(3,5));
            jsonDoc["programas"][i]["horaParada"] = horas * 60 + minutos;
            jsonDoc["programas"][i]["estadoAdmin"] = document.querySelector(`.p${i}AdminStatus`).checked;
            for (let j = 1; j < 8; j++)
            {
                jsonDoc["programas"][i]["dias"][j] = document.querySelector(`.p${i}${j}`).checked;
            }
        }
        jsonDoc["wifiSTA"]["SSID"] = document.querySelector(".ssid").value;
        jsonDoc["wifiSTA"]["PWD"] = document.querySelector(".pwd").value;
        jsonDoc["wifiSTA"]["ipAddress"] = document.querySelector(".ipAddress").value;
        jsonDoc["wifiSTA"]["netMask"] = document.querySelector(".mask").value;
        jsonDoc["wifiSTA"]["gateway"] = document.querySelector(".gtw").value;
        jsonDoc["wifiSTA"]["dns"] = document.querySelector(".dns").value;
        jsonDoc["ntpServerName"] = document.querySelector(".ntp").value;
        jsonDoc["zonaHoraria"] = document.querySelector(".tz").value;
    }

    xhttp.onreadystatechange = function() {
        if (xhttp.readyState === XMLHttpRequest.DONE) {
           if (xhttp.status === 200 && toBeSave)
           {
               alert("Los cambios han sido aplicados");
           }
           else if (xhttp.status !== 200 && toBeSave)
           {
                alert("Los cambios no han podido ser aplicados.\nPor favor, intentalo de nuevo pasado unos segundos");
           }
        }
    }
    let serialJson = JSON.stringify(jsonDoc);
    console.log(serialJson);
    xhttp.open('POST', '/postJson');
    xhttp.setRequestHeader('Content-Type', 'application/json');
    xhttp.send(serialJson);

}

function queryJson() {
 
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (xhttp.readyState === XMLHttpRequest.DONE) {
           if (xhttp.status === 200) {
			    console.log((xhttp.responseText));
			    jsonDoc = JSON.parse(xhttp.responseText);
                const fecha = `Hoy es ${jsonDoc["dia"]} del ${jsonDoc["mes"]} del ${jsonDoc["ano"]}`;
                document.querySelector('.skeletonDateText').textContent = fecha;

                for (let i = 1; i < 5; i++)
                {
                    let horas = (jsonDoc["programas"][i]["horaArranque"] / 60).toFixed(0);
                    let minutos = (jsonDoc["programas"][i]["horaArranque"] % 60).toString();
                    if (horas.length < 2) horas = `0${horas}`;
                    if (minutos.length < 2) minutos = `0${minutos}`;
                    document.querySelector(`.p${i}starttime`).value = `${horas}:${minutos}`;
                    horas = (jsonDoc["programas"][i]["horaParada"] / 60).toFixed(0);
                    minutos = (jsonDoc["programas"][i]["horaParada"] % 60).toString();
                    if (horas.length < 2) horas = `0${horas}`;
                    if (minutos.length < 2) minutos = `0${minutos}`;
                    document.querySelector(`.p${i}stoptime`).value = `${horas}:${minutos}`;
                    document.querySelector(`.p${i}AdminStatus`).checked = jsonDoc["programas"][i]["estadoAdmin"];
                    if (jsonDoc["programas"][i]["estadoProg"])
                    {
                        document.querySelector(`.p${i}`).style.backgroundColor = "rgb(35, 160, 9)";
                    }
                    else
                    {
                        document.querySelector(`.p${i}`).style.backgroundColor = "transparent";
                    }
                    for (let j = 1; j < 8; j++)
                    {
                        document.querySelector(`.p${i}${j}`).checked = jsonDoc["programas"][i]["dias"][j];
                    }
                }

                document.querySelector(".ssid").value = jsonDoc["wifiSTA"]["SSID"];
                document.querySelector(".pwd").value = jsonDoc["wifiSTA"]["PWD"];
                document.querySelector(".ipAddress").value = jsonDoc["wifiSTA"]["ipAddress"];
                document.querySelector(".mask").value = jsonDoc["wifiSTA"]["netMask"];
                document.querySelector(".gtw").value = jsonDoc["wifiSTA"]["gateway"];
                document.querySelector(".dns").value = jsonDoc["wifiSTA"]["dns"];
                document.querySelector(".ntp").value = jsonDoc["ntpServerName"];
                document.querySelector(".tz").value = jsonDoc["zonaHoraria"];

                if (jsonDoc["gestionManual"]["depuradora"])
                {
                    document.querySelector('.botonDepuradora').textContent = 'Parar Depuradora';
                    document.querySelector('.botonDepuradora').style.backgroundColor = "red";
                    document.querySelector('.botonDepuradora').style.color = "black";
                }
                if (jsonDoc["gestionManual"]["luz"])
                {
                    document.querySelector('.botonLuz').textContent = 'Apagar Luz';
                    document.querySelector('.botonLuz').style.backgroundColor = "red";
                    document.querySelector('.botonLuz').style.color = "black";
                }
                if (jsonDoc["gestionManual"]["bomba"])
                {
                    document.querySelector('.botonBomba').textContent = 'Parar Bomba';
                    document.querySelector('.botonBomba').style.backgroundColor = "red";
                    document.querySelector('.botonBomba').style.color = "black";
                }	   
			}
           else {
              console.log('error', xhttp);
           }
        }
    };
 
    xhttp.open("GET", "/queryJson", true);
    xhttp.send();
}

function heartbeat() {

    let xhttp = new XMLHttpRequest();
    
    xhttp.onreadystatechange = function() {
        if (xhttp.readyState === XMLHttpRequest.DONE)
        {
           if (xhttp.status === 200)
           {
               document.querySelector(".connectionText").textContent = "Conectado";
               document.querySelector(".connectionText").style.color = "darkblue";
               document.querySelector(".connectionImage").src = "https://img.icons8.com/external-flat-icons-inmotus-design/67/000000/external-connect-network-connection-flat-icons-inmotus-design-2.png";
               document.querySelector(".connectionImage").style.backgroundColor = "transparent";
               btnDepuradora.disabled = false;
               btnLuz.disabled = false;
               btnBomba.disabled = false;
               btnApCambios.disabled = false;
               btnDepuradora.style.opacity = "1";
               btnLuz.style.opacity = "1";
               btnBomba.style.opacity = "1";
               btnApCambios.style.opacity = "1";
               heartbeatRetries = 0;
               console.log("Respuesta del Heartbeat");
           }
           else if (heartbeatRetries === 3)
           {
                document.querySelector(".connectionText").textContent = "Se ha perdido la connexión";
                document.querySelector(".connectionText").style.color = "red";
                document.querySelector(".connectionImage").src = "https://img.icons8.com/external-xnimrodx-lineal-gradient-xnimrodx/64/000000/external-signal-notification-alert-xnimrodx-lineal-gradient-xnimrodx.png";
                document.querySelector(".connectionImage").style.backgroundColor = "red";
                btnDepuradora.disabled = true;
                btnLuz.disabled = true;
                btnBomba.disabled = true;
                btnApCambios.disabled = true;
                btnDepuradora.style.opacity = "0.5";
                btnLuz.style.opacity = "0.5";
                btnBomba.style.opacity = "0.5";
                btnApCambios.style.opacity = "0.5";
                console.log("Sin respuesta del Heartbeat en mas de 3 ocasiones");
           }
           else
           {
               heartbeatRetries++;
               console.log("Sin respuesta del Heartbeat");
           }
        }
    }
    xhttp.open("GET", "/heartbeat", true);
    xhttp.send();
}
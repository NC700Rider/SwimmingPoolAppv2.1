/*Las funciones de gestion de ficheros JSON requieren de dos variable globales
 * La variable serialJson que es donde estará el documento json serializado
 * y la variable jsonDoc que es donde esta el documento json deserializado
 */

void inicializacionFS() { // Iniciando el sistema de ficheros SPIFFS
  
  Serial.println("\nMontando FS...");
  bool isFSmount = SPIFFS.begin();
  if (isFSmount) {
    Serial.println("\nSe ha montado sistema de ficheros");
  } else {
    Serial.println("\nError al montar el sistema de ficheros");
    }
}


bool readJson() {
  // Abriendo el fichero JSON
  File progFile = SPIFFS.open(fileJson, "r");
  if (!progFile) {
    Serial.println("\nError: al leer el fichero de programacion");
    return false;
  }

  // Deserializa el fichrero programacion.json y lo mete en el objeto doc
  DeserializationError error = deserializeJson(jsonDoc, progFile);
  serializeJson(jsonDoc, serialJson);
  Serial.println("Este es el JSON recien leido del sistema de ficheros:");
  Serial.println(serialJson);

  if (error) {
    Serial.println("deserializeJson() ha fallado con el codigo");
    Serial.println(error.c_str());
    return false;
  }

  progFile.close();
  return true;
}



bool writeJson() {
  // Abriendo el fichero JSON
  if (jsonDoc["escribir"] == false)
  {
    Serial.println("Nada que escribir en SPIFF");
    return false;
  }
  //Reiniciamos esas variables que manualmente activan dispositivos para evitar que ante un reinicio se activen
  for ( uint8_t numProg = 0; numProg < 4; numProg++)
  {
    jsonDoc["programas"][numProg]["estadoProg"] = false;
  }
  jsonDoc["gestionManual"]["depuradora"] = false;
  jsonDoc["gestionManual"]["luz"] = false;
  jsonDoc["gestionManual"]["bomba"] = false;
  jsonDoc["gestionManual"]["segundosArranqueClorador"] = 0;
  jsonDoc["escribir"] = false;
  File progFile = SPIFFS.open(fileJson, "w");
  if (!progFile) {
    Serial.println("\nError: al abrir el fichero de programacion durante la escritura");
    return false;
  }
  serialJson = "";
  serializeJson(jsonDoc,serialJson);
  Serial.println("Este es el JSON antes de escribirlo en el sistema de ficheros:");
  Serial.println(serialJson);
  int bytesWritten = progFile.print(serialJson);
 
   if (bytesWritten > 0) {
    Serial.println("File was written");
    Serial.println(bytesWritten);
 
    }
    else {
      Serial.println("File write failed");
      return false;
      }

  progFile.close();
  return true;
}

//Inicializacion de la connexion WiFi

void inicializacionWiFi() {

  const char* ssid = jsonDoc["wifiSTA"]["SSID"].as<const char*>();
  const char* pass = jsonDoc["wifiSTA"]["PWD"].as<const char*>();
  const char* ssid_AP = jsonDoc["wifiAP"]["SSID"].as<const char*>();
  const char* pass_AP = jsonDoc["wifiAP"]["PWD"].as<const char*>();

  int i = 0;
  WiFi.mode(WIFI_AP_STA);
  WiFi.config(str2IP(jsonDoc["wifiSTA"]["ipAddress"]), str2IP(jsonDoc["wifiSTA"]["gateway"]), str2IP(jsonDoc["wifiSTA"]["netMask"]), str2IP(jsonDoc["wifiSTA"]["dns"]));
  WiFi.softAP(ssid_AP, pass_AP);
  if (strlen(ssid) > 0)
  {
      WiFi.begin(ssid, pass);
      for ( i = 0; WiFi.status() != WL_CONNECTED && i < 60 ; i++) {
        delay(500);
        Serial.print(".");
      }
     if (WiFi.status() == WL_CONNECTED)
     Serial.print("\nConectado a WiFi");  
  }

    
  WiFi.printDiag(Serial);
  Serial.println(WiFi.localIP());
}

void checkWifiStatus ()
{
  if (WiFi.status() == WL_CONNECTED)
    Serial.println("Conectado a WiFi");
  else
    Serial.println("Desconectado de WiFi");
}

AsyncWebServer server(80);

/*
 * A continuacion se declaran todas las funciones o API REST que se implementan como parte del Web Server  
 */

void queryJson(AsyncWebServerRequest *request)
{
  Serial.println("Entro en la funcion queryJson");
  jsonDoc["dia"] = day();
  jsonDoc["mes"] = month();
  jsonDoc["ano"] = year();
  jsonDoc["hora"] = hour();
  jsonDoc["minuto"] = minute();
  AsyncResponseStream *response = request->beginResponseStream("application/json");
  serializeJson(jsonDoc, *response);
  request->send(response);
}

void postJson(AsyncWebServerRequest *request, uint8_t *data, size_t len, size_t index, size_t total)
{
  Serial.println("Entro en la funcion postJson");
  if(!index){
    Serial.printf("BodyStart: %u B\n", total);
    serialJson = "";
  }
  
  for(size_t i=0; i<len; i++){
    Serial.write(data[i]);
    serialJson.concat((char)data[i]);
  }
  if(index + len == total){
    Serial.printf("BodyEnd: %u B\n", total);
    Serial.println("********************************************");
    Serial.println(serialJson);
    DeserializationError error = deserializeJson(jsonDoc, serialJson);
    Serial.println(error.f_str());
    if (error) { request->send(400); return;}
    Serial.println("********************************************");
  }

  request -> send(200);
}


/*
 * Inicializacion del servidor Web
 */

void inicializacionWebServer()
{
   server.serveStatic("/", SPIFFS, "/").setDefaultFile("main.html");

   server.on("/queryJson", HTTP_GET, queryJson);
   server.on("/postJson", HTTP_POST, [](AsyncWebServerRequest * request){}, NULL, postJson);
   server.on("/heartbeat", [](AsyncWebServerRequest *request) {
      request->send(200, "text/plain", "Alive");
   });

   server.onNotFound([](AsyncWebServerRequest *request) {
      request->send(400, "text/plain", "Not found");
   });
 
   server.begin();
   Serial.println("HTTP server started");
}

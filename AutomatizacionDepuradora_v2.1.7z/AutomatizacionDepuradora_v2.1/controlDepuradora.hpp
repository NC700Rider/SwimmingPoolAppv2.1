//Funciones de gestion de la depuradora
//--------------------------------------------------------

void gestionProgramacion()
{
  /*
   * En la gestion de la programacion debemos tener en cuenta las siguientes consideraciones:
   * - El dia 1 es el domingo
   * - La hora de Arranque y de Parada estan en formato de numero de minutos desde la 00:00 horas del dia
   */
  Serial.println("Entro en la funcion gestionprogramacion");
  uint16_t horaActual = hour() * 60 + minute();
  for (uint8_t numProg = 1; numProg < 5; numProg++)
  {
    if (jsonDoc["programas"][String(numProg)]["estadoAdmin"])
    {
      if (jsonDoc["programas"][String(numProg)]["dias"][String(weekday())])
      {
         if ((horaActual >= jsonDoc["programas"][String(numProg)]["horaArranque"]) && (horaActual < jsonDoc["programas"][String(numProg)]["horaParada"]))
        {
          jsonDoc["programas"][String(numProg)]["estadoProg"] = true;
        }
        else
        {
          jsonDoc["programas"][String(numProg)]["estadoProg"] = false;
        }
      }
      else
      {
        jsonDoc["programas"][String(numProg)]["estadoProg"] = false;
      }
    }
    else
    {
      jsonDoc["programas"][String(numProg)]["estadoProg"] = false;
    }
  }
}

void gestionDispositivos()
{
  Serial.println("Entro en la funcion gestionDispositivos");
  bool estadoProgramas = false;
  for ( uint8_t numProg = 1; numProg < 5; numProg++)
  {
    estadoProgramas = estadoProgramas || (jsonDoc["programas"][String(numProg)]["estadoProg"] && jsonDoc["programas"][String(numProg)]["estadoAdmin"]);
  }
  //Determino el estado de la Bomba
  if (estadoProgramas || jsonDoc["gestionManual"]["depuradora"] || jsonDoc["gestionManual"]["bomba"])
  {
    digitalWrite(bomba, HIGH);
  }
  else
  {
    digitalWrite(bomba, LOW);
  }

  //Determino el estado del Clorador
  if (estadoProgramas || jsonDoc["gestionManual"]["depuradora"])
  {
    if (jsonDoc["gestionManual"]["segundosArranqueClorador"].as<long>() == 0)
    {
      digitalWrite(clorador, HIGH);
      jsonDoc["gestionManual"]["segundosArranqueClorador"] = now();
    }
    if ((now() > (jsonDoc["gestionManual"]["segundosArranqueClorador"].as<long>() + 10)) && (now() < (jsonDoc["gestionManual"]["segundosArranqueClorador"].as<long>() + 20)))
    {
      digitalWrite(clorador, LOW);
    }
    if (now() > (jsonDoc["gestionManual"]["segundosArranqueClorador"].as<long>() + 20))
    {
      digitalWrite(clorador, HIGH);
    }
  }
  else
  {
    digitalWrite(clorador, LOW);
    jsonDoc["gestionManual"]["segundosArranqueClorador"] = 0;
  }

  //Determino el estado de la Luz
  if (jsonDoc["gestionManual"]["luz"])
  {
    digitalWrite(luz, HIGH);
  }
  else
  {
    digitalWrite(luz, LOW);
  }
}
